/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreportapp;

/**
 *
 * @author ntatiso
 */
public class PrintProduct {


    private final Product product;

    public PrintProduct(Product product) {
        this.product = product;
    }

    public void printHeading() {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("*".repeat(34));
    }

    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void printAverageProductSales() {
        double average = product.GetAverageProductSold();
        if (average == Math.floor(average)) {
            System.out.println("AVERAGE PRODUCT SALES: " + (int) average);
        } else {
            System.out.printf("AVERAGE PRODUCT SALES: %.2f%n", average);
        }
    }

    public void printMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct()
                + " (" + product.GetMostPopularTotal() + ")");
    }
}
    

