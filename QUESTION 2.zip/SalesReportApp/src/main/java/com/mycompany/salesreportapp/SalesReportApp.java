/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salesreportapp;
import java.util.Scanner;
/**
 *
 * @author ntatiso
 */
public class SalesReportApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        
        String[] productNames = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};

        int[][] sales = new int[productNames.length][3];

        for (int p = 0; p < productNames.length; p++) {
            for (int m = 0; m < 3; m++) {
                sales[p][m] = readSales(input, m + 1, productNames[p]);
            }
            System.out.println();
        }

        Product product = new Product(productNames, sales);
        PrintProduct printer = new PrintProduct(product);

        printer.printHeading();
        printer.printTotalProductSales();
        printer.printAverageProductSales();
        printer.printMostPopularProduct();
    }

    private static int readSales(Scanner input, int month, String productName) {
        while (true) {
            System.out.print("Enter number of sales for month " + month
                    + " for " + productName + " mattress: ");
            try {
                int value = Integer.parseInt(input.nextLine().trim());
                if (value >= 0) {
                    return value;
                }
                System.out.println("Please enter a number that is 0 or more.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }
    }
}
        
    

