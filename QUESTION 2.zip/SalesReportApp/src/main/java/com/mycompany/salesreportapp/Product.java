/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.salesreportapp;

/**
 *
 * @author ntatiso
 */

public class Product implements IProduct {

    private final String[] productNames; 
    private final int[][] sales;

    public Product(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    }

    public int GetProductTotal(int productIndex) {
        int total = 0;
        for (int month = 0; month < sales[productIndex].length; month++) {
            total += sales[productIndex][month];
        }
        return total;
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int p = 0; p < sales.length; p++) {
            total += GetProductTotal(p);
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int count = 0;
        for (int[] row : sales) {
            count += row.length;
        }
        if (count == 0) {
            return 0;
        }
        return (double) GetTotalProductsSold() / count;
    }

    private int GetMostPopularIndex() {
        int best = 0;
        for (int p = 1; p < sales.length; p++) {
            if (GetProductTotal(p) > GetProductTotal(best)) {
                best = p;
            }
        }
        return best;
    }

    @Override
    public String GetMostPopularProduct() {
        if (sales.length == 0) {
            return "None";
        }
        return productNames[GetMostPopularIndex()];
    }

    public int GetMostPopularTotal() {
        if (sales.length == 0) {
            return 0;
        }
        return GetProductTotal(GetMostPopularIndex());
    }
}
    

